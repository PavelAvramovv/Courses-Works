#pragma warning(disable : 4996)
#include <stdlib.h> // For exit() function
#include <stdio.h>
#include <string.h>

char* screen(char c[])
{
	strcat(c, "wrld");
	return c;
}

FILE *open_file(char* filename, char* mode)
{
	FILE *f;
	f = fopen(filename, mode);
	if (!f)
	{
		perror(filename);
			exit(EXIT_FAILLURE);
	}
}

int main()
{
	char asd[]="";
	//file(asd);


	
}



/*


int sum(int n1, int n2) {
	int result = n1 * n2;
	return result;
	printf("%d", result);
}

int main() {
	int rec;
	int num1;
	int num2;
	scanf("%d", &num1);
	scanf("%d", &num2);
	rec = sum(num1, num2);
	printf("%d", rec);
	return 0;
}




*/


/*

int a;
int b;
int ret;
printf("a:");
scanf("%d", &a);
printf("b:");
scanf("%d", &b);

/// calling a function to get max value
ret = max(a, b);

printf("Max value is : %d\n", ret);
*/








/*
char c[1000];
FILE *fptr;
if ((fptr = fopen("asd.txt", "r")) == NULL) {
	printf("Error! opening file");
	// Program exits if file pointer returns NULL.
	exit(1);
}

// reads text until newline is encountered
fscanf(fptr, "%[^\n]", c);
printf("Data from the file:\n%s", c);
fclose(fptr);

return 0;*/
